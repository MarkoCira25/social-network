<?php 
/*
servername = "localhost";
username = "root";
password = "";
dbname

define("SERVERNAME", "localhost")
*/

const SERVERNAME = "localhost";
const USERNAME = "root";
const PASSWORD = "";
const DBNAME = "soc_net";
?>